--
-- backup20180805-123935.sql.gz


DROP TABLE IF EXISTS `eleve`;
CREATE TABLE `eleve` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `ville` varchar(20) NOT NULL,
  `profession` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `etablissement` varchar(20) NOT NULL,
  `classe` varchar(20) NOT NULL,
  `tel` int(11) NOT NULL,
  `somme` int(11) NOT NULL,
  `receptioniste` varchar(20) NOT NULL,
  `avatar` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `categorie` varchar(20) NOT NULL,
  `formation` varchar(20) NOT NULL,
  `session` varchar(10) NOT NULL,
  `etude` varchar(20) NOT NULL,
  `preference` varchar(20) NOT NULL,
  `instrument` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `eleve` VALUES ('1','Ted','isco','yaoundé','Etudiant','12','','','655555555','150000','Cedinho','default.png','2018-06-13','Jeune','Individuelle','Juin','Piano','Matin 08h00 - 12h30','piano');


DROP TABLE IF EXISTS `notification`;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ideleve` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `mois` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `notification` VALUES ('7','2','gilles','cedric','07');


DROP TABLE IF EXISTS `paiement`;
CREATE TABLE `paiement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ideleve` int(11) NOT NULL,
  `somme` int(11) NOT NULL,
  `date` date NOT NULL,
  `dateprochaine` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `paiement` VALUES ('5','1','5400','2018-06-07','2018-07-07');
INSERT INTO `paiement` VALUES ('7','1','3600','2018-06-22','2018-07-22');
INSERT INTO `paiement` VALUES ('8','1','12500','2018-06-12','2018-07-12');
INSERT INTO `paiement` VALUES ('9','2','4590','2018-06-24','2018-07-24');
INSERT INTO `paiement` VALUES ('10','2','4588','2018-06-17','2018-07-17');
INSERT INTO `paiement` VALUES ('11','2','3600','2018-07-24','2018-08-24');
INSERT INTO `paiement` VALUES ('12','2','12500','2018-07-24','2018-08-24');
INSERT INTO `paiement` VALUES ('13','2','4566','2018-07-25','2018-08-25');


DROP TABLE IF EXISTS `tuteur`;
CREATE TABLE `tuteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `teltuteur` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tuteur` VALUES ('1','ddee','hyjjj','633333333','ted@yahoo.fr');
INSERT INTO `tuteur` VALUES ('3','fvsvsvfvs','vsvsvs','57667777','ngceefe@fefefe.fefe');


DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `habilitation` varchar(20) NOT NULL,
  `tel` int(10) NOT NULL,
  `avatar` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `utilisateur` VALUES ('3','Gilles','Cedric','Cedinho','Cedinho10','nguefackgilles@gmail.com','Administrateur','698158192','default.png');
INSERT INTO `utilisateur` VALUES ('4','Jean','Jacques','jean','aaaaaaaa','jean@gmail.com','Utilisateur','677456324','default.png');
